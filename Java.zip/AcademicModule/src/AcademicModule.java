public class AcademicModule
{
    public static void main(String[]args)
    {
        int num=0;
        if (num>70)
        {
            System.out.println("A");
        }
        {
            else(num<70);
                    {
                        System.out.println("F");
                        
                    }
        }
    }
        }
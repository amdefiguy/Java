public class JavaIntExample
{
    public static void main(String[]args)
    {
        int i=5;
    double z,j=7.5;
    z=i+j;
        System.out.println("sum is:"+z);
    }
}